﻿using Match3.Core.Interfaces;

namespace Terminal.Match3.Interfaces
{
    public interface IGridTile : IGridSlotState
    {
    }
}