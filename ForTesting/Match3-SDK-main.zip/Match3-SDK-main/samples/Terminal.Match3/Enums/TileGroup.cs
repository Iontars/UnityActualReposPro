﻿namespace Terminal.Match3.Enums
{
    public enum TileGroup
    {
        Unavailable = 0,
        Available = 1,
        Locked = 2
    }
}