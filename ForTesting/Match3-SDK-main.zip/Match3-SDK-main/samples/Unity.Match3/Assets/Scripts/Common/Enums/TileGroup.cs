namespace Common.Enums
{
    public enum TileGroup
    {
        Unavailable = 0,
        Available = 1,
        Ice = 2,
        Stone = 3
    }
}