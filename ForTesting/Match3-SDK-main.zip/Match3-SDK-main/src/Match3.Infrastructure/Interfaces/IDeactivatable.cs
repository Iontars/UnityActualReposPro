﻿namespace Match3.Infrastructure.Interfaces
{
    public interface IDeactivatable
    {
        void Deactivate();
    }
}