using Task_1.Scripts.Main;

namespace Task_1.Scripts.Menu_03
{
    public class MusicPanelHandler : UIHandler<MusicPanel>
    {
    
    }
}
