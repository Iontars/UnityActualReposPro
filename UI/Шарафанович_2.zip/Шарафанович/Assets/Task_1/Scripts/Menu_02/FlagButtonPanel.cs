using Task_1.Scripts.Main;

namespace Task_1.Scripts.Menu_02
{
    public class FlagButtonPanel : UIPanel
    {
        //Возможные расширения
    }
}
