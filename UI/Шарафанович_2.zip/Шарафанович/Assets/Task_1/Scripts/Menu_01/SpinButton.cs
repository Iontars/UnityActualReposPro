using Task_1.Scripts.Main;

namespace Task_1.Scripts.Menu_01
{
    public class SpinButton : InteractionElement
    {
    
    }
}
