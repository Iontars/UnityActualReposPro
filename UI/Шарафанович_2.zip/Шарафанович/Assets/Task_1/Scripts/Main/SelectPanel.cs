
namespace Task_1.Scripts.Main
{
    public class SelectPanel : UIPanel
    {
    
    }
}
