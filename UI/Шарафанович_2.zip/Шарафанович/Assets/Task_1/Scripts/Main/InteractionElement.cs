using UnityEngine;

namespace Task_1.Scripts.Main
{
    public abstract class InteractionElement : MonoBehaviour
    {
        protected void DoAction(int value)
        {
        
        }
    }
}
