namespace Task_1.Scripts.Main
{
    public class UIMenuHandler : UIHandler<SelectPanel>
    {
    
    }
}
