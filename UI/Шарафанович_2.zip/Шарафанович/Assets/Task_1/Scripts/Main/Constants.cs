
using UnityEngine;

namespace Task_1.Scripts.Main
{
    public static class Constants
    {
        public const int rightTimerValue = 59;
        public const int leftTimerValue = 23;

        public static readonly int PopupStartAnim = Animator.StringToHash("IsPlaying");
        public static readonly int BoardFadeStartAnim = Animator.StringToHash("BoardFade");
        public static readonly int BackgroundFadeStartAnim = Animator.StringToHash("BackgroundFade");
        public static readonly string MainPopupAnimName = "MainPopup";
        public static readonly string BoardFadeAnimName = "isRun_2";
        public static readonly string BackgroundAnimName = "isRun";
    }
}
